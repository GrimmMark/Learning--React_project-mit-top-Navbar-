export const About = () => {
  return <div className="aboutP">
    <h1>Impressum</h1>
    <h2>ReDi-School</h2>
    <p>Rosenheimerstr. 139</p>
    <p>81369 Munich</p>
    <p>Bavaria</p>
    <p>Germany</p>
    <h2> Disclaimer </h2>
    <p> Isch wars nüsch...</p>
    <p> Wirklich nüsch...</p>
    <p> Und übernehm auch keine Verantwortung für wen anders...</p>
    <p>PEEZE</p>
  </div>;
};
