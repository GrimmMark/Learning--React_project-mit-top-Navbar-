import { useContext } from "react";
import { AppContext } from "../App";

export const Home = () => {
  const { username } = useContext(AppContext);
  return <div className="homeP">
    <h1>HOME</h1>
    <h2>{username}</h2>

  </div>;
};
