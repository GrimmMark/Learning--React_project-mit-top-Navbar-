import { useContext } from "react";
import { ChangeProfile } from "../ChangeProfile";
import { AppContext } from "../App";


export const Profile = () => {
  const { username } = useContext(AppContext);
  return (
    <div className="profileP">
      
      <div className="change">
        <ChangeProfile />
      </div>
      <h1>{username}</h1>
    </div>
  );
};