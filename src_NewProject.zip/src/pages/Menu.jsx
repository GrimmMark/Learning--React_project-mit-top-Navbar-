export const Menu = () => {
  return <div className="menuP">
    <h1>MENU</h1>
  </div>;
};
