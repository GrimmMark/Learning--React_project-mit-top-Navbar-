import "./App.css";

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// import pages to jump to
import { Home } from "./pages/Home";
import { Menu } from "./pages/Menu";
import { About } from "./pages/About";
import { Contact } from "./pages/Contact";
import { Profile } from "./pages/Profile";
import { Navbar } from "./Navbar";
import { useState, createContext } from "react";
// need to install : npm install react-router-dom

export const AppContext = createContext();

function App() {
  const [username, setUserName] = useState('"TheJeff" aka MarkyMark');
  return (
    <div className="App">
      {/* this is where the routes shall be in the code - Router */}
      <AppContext.Provider value={{ username, setUserName }}>
        <Router>
          {/* adding our component Navbar fixed on top */}
          <Navbar />
          {/* here now the different pages incl. path to jump to and change screen below Navbar */}
          <Routes>
            <Route path="/menu" id="relement" element={<Menu />} />
            <Route path="/" id="relement" element={<Home />} />
            <Route path="/profile" id="relement" element={<Profile />} />
            <Route path="/contact" id="relement" element={<Contact />} />
            <Route path="/about" id="relement" element={<About />} />
            {/* having a error page when no path found */}
            <Route path="*" element={<h1> PAGE NOT FOUND</h1>} />
          </Routes>
        </Router>
      </AppContext.Provider>
    </div>
  );
}

export default App;
