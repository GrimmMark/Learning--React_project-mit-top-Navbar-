import { Link } from "react-router-dom"; // import link component

export const Navbar = () => {
  return (
    <div className="Navbar">
      {/* using Link to adress the different pages like defined before in <Routes> */}
      <Link className="nav" to="/menu"> Menu </Link>
      <Link className="nav" to="/"> Home </Link>
      <Link className="nav" to="/profile"> Profile </Link>
      <Link className="nav" to="/contact"> Contact  </Link>
      <Link className="nav" to="/about"> About </Link>
    </div>
  );
};
